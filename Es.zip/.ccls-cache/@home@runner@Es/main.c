#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 20

int dimensioneMatrice();
void creaMatrice(int matrice[DIM][DIM]);
void stampaMatrice(int matrice[DIM][DIM]);

int dimensioneMatrice() {
  int dim;
  printf("Inserisci dim: ");
  scanf("%d", &dim);
  return dim;
}

void creaMatrice(int matrice[DIM][DIM]) {
  int dim = dimensioneMatrice();
  srand(time(NULL));

  for (int i = 0; i < dim; i++) {
    for (int f = 0; f < dim; f++) {
      matrice[i][f] = (rand() % dim + 1);
    }
  }
}

void stampaMatrice(int matrice[DIM][DIM]) {
  
  int dim = dimensioneMatrice();
  printf("STAMPA SENZA LEGGERE DA CSV");

  for (int i = 0; i < dim; i++) {
    printf("\nriga\t%d |", i);
    for (int f = 0; f < dim; f++) {
      printf("\t\t%d", matrice[i][f]);
    }
  }
  
}
void salvaSuCsv(int matrice[DIM][DIM])
{
  int dim=dimensioneMatrice();
  FILE* fp = fopen("matriceSuFileCsv.csv", "w");
    for(int i=0; i<dim; i++) {
        for(int f=0; f<dim; f++) {
            fprintf(fp, "%d", matrice[i][f]);
            if(f!=dim-1) {
                fprintf(fp, ",");
            }
        }
        fprintf(fp, "\n");
    }
    fclose(fp);
   
}
void stampaSuCsv(int matrice[DIM][DIM]){
  int dim=dimensioneMatrice();
  FILE* fp = fopen("matriceSuFileCsv.csv", "r");
    if(fp == NULL) {
        printf("errore");
    }
    printf("\nMATRICE LETTA DAL FILE CSV:\n\t");
    for(int i=0; i<dim; i++) {
        for(int f=0; f<dim; f++) {
            fscanf(fp, "%d", &matrice[i][f]);
            printf("%d ", matrice[i][f]);
        }
        printf("\n");
    }
    fclose(fp);
}
int main() {
  int scelta, dim;
  int matrice[DIM][DIM];

  do {
    printf("\nInserire la scelta (0 per terminare)(1 per caricare e stampare  la matrice)(2 per stampare la matrice dal file csv): ");
    scanf("%d", &scelta);

    switch(scelta) {
    case 0:
      printf("\n\nTermina il programma");
      break;
    case 1:
      creaMatrice(matrice);
      stampaMatrice(matrice);
      
      break;
    case 2:
      salvaSuCsv(matrice);
      stampaSuCsv(matrice);
      break;
  
    
   
    }
  } while (scelta != 0);

  return 0;
}
